//Requiring and calling modules
(
    function (module1, module2) {
        console.log("modules has been successfully loaded!");
    }
)

(sayHello, printNumber);

sayHello.doWork();
printNumber.doWork();